// Gra działa także bez internetu (poza grą online): pliki trzymamy w pamięci przeglądarki.
const CACHE = 'wiezien-68db3abd8a';
const PLIKI = ['./', './index.html', './manifest.webmanifest', './ikona-180.png', './ikona-192.png', './ikona-512.png', './ikona-maskowalna-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(PLIKI)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(n => n !== CACHE).map(n => caches.delete(n)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const u = new URL(e.request.url);
  if (u.origin !== location.origin) return;
  // strona gry: najpierw z internetu (nowa wersja od razu), bez internetu - z pamięci
  if (e.request.mode === 'navigate') {
    e.respondWith(fetch(e.request).then(r => { const kopia = r.clone(); caches.open(CACHE).then(c => c.put('./index.html', kopia)); return r; })
      .catch(() => caches.match('./index.html')));
    return;
  }
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
